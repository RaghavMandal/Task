Task

In order amount is 100 or more the customer is loyal apply a 10% discount 
otherwise, no discount applied.
Display the calculated discount and final order total on result on a page


1.First I get the one textbox and two lables.

2.After i text_changed event is used.

3.In that first checks the condition of textbox is greater than or equal to 100.

4.It is order amount is grater than or equal to 100 then 10% discount is appiled.

5.It is order amount is less than 100 to do not applied on 10% discount & show the message.

6.And After we all calculated to amount is display.