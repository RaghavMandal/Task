﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Task : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    

protected void txtOrderAmount_TextChanged(object sender, EventArgs e)
{
    decimal orderAmount = decimal.Parse(txtOrderAmount.Text); 

  
    if (orderAmount >= 100)
    {
        
        decimal discountPercentage = 10; 
        decimal discountAmount = orderAmount * (discountPercentage / 100);
       
        decimal discountedPrice = orderAmount - discountAmount;
       
        lblDiscountAmount.Text = discountAmount.ToString("C");
        lblDiscountedPrice.Text = discountedPrice.ToString("C");
        lblMessage.Text = "";
        
    }
    else
    {

        //decimal discountPercentage = 10;
        decimal discountAmount = orderAmount * 0;

        decimal discountedPrice = orderAmount + discountAmount;

        lblDiscountAmount.Text = discountAmount.ToString("C");
        lblDiscountedPrice.Text = discountedPrice.ToString("C");
        lblMessage.Text = "";
       
       
        lblMessage.Text = "No discount applied.";
    }
    
    
}
}